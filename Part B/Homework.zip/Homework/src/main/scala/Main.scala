object Main {
  def main(args: Array[String]): Unit = {
//    println(Question01.insertAtPosition(177 , 0, List(1,2,3,4,5,6)))

//    println(Question02.insertInOrder(0 , List(1,2,7,9,10)))

//    println(Question03.subList(List() , List(4,5,6,7,8,9)))

//    println(Question04.palindrome(List()))

      println(Question05.mergesort(List(2,1,9,1,20,0,5)))

//    def isLessThan3(x:Int) = x<3
//    println(Question06.myFilter(x => x%2==0)(List(1,2,3,4,5))) // จะได้ List(2,4)
//    println(Question06.myFilter(isLessThan3)(List(1,2,3,4,5)))  //จะได้ List(1,2) ถ้ามีการเขียน def

//    def square(x:Int) : Int = x*x
//    println(Question07.myMap(x => x*2)(List(1,2,3,4,5))) // จะได้ List(2,4,6,8,10)
//    println(Question07.myMap(square)(List(1,2,3,4,5))) // จะได้ List(1,4,9,16,25)

//    println(Question08.maxAll(List()))
//    println(Question08.maxAll(List(List())))
//    println(Question08.maxAll(List(List(1,2,3,4,8,9),List(),List(4,5),List(1,2,3,5,6,10,11))))
//    println(Question08.maxAll(List(List(3,4),List(1,2,3,4,51,61),List(1,2,31,41,61,51))))
//    println(Question08.maxAll(List(List(1,2,3,40,5,6),List(10,2,30,4),List(1,200),List(0,0,0,0,0,0,0,0,9))))
//    List()
//    List()
//    List(4, 5, 3, 5, 8, 10,11)
//    List(3, 4, 31, 41, 61, 61)
//    List(10, 200, 30, 40, 5, 6, 0, 0, 9

//    def f1(c: Char) : Char = c.toLower
//    val tape = List('C', 'H', 'A', 'R')
//    println(Question09.turingStep(f1,tape,2))
//    println(Question09.turingStep(f1,tape,3))
//    println(Question09.turingStep(f1,tape,0))
//    println(Question09.turingStep(f1,tape,5))
//    List(c, h, A, R)
//    List(c, h, a, R)
//    List(C, H, A, R)
//    List(c, h, a, r)

//    def f1(a:Int , b:Int) = a+b
//    def f2(a:Int , b:Int) = a-b
//    println(Question10.alternate(f1,f2,List())) // ได้ผลลัพธ์เป็น 0
//    println(Question10.alternate(f1,f2,List(55))) // ได้ผลลัพธ์ 55
//    println(Question10.alternate(f1,f2,List(1,2)))//ได้ผลลัพธ์ = 1+2 = 3
//    println(Question10.alternate(f1,f2,List(1,2,3))) //ได้ผลลัพธ์ =1+2-3 = 0
//    println(Question10.alternate(f1,f2,List(1,2,3,4))) //ได้ผลลัพธ์ =1+2-3+4 = 4
  }
}
